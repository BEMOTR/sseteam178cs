package model.collectibles;

public class Supply {
	public Supply() {
		
	}
}
