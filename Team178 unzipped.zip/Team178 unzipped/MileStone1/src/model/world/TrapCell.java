package model.world;

public class TrapCell extends Cell{
	private int trapDamage ;
	
	public TrapCell() {
		super();
	}

	public int getTrapDamage() {
		return trapDamage;
	}
	

}
